## ---- echo=FALSE, message=FALSE------------------------------------------
nodes <- read.csv("congress-twitter-network-nodes.csv")
edges <- read.csv("congress-twitter-network-edges.csv")
library(igraph)
g <- graph_from_data_frame(d=edges, vertices=nodes, directed=TRUE)
g <- decompose(g)[[1]]

## ------------------------------------------------------------------------
assortativity_degree(g, directed=FALSE)
assortativity(g, log(V(g)$followers_count), directed=FALSE)
assortativity_nominal(g, factor(V(g)$chamber))
assortativity_nominal(g, factor(V(g)$party))
assortativity_nominal(g, factor(V(g)$gender))

## ------------------------------------------------------------------------
prop.table(table(V(g)$gender, V(g)$party), margin=2)

## ------------------------------------------------------------------------
library(intergraph)
library(network)
net <- asNetwork(g)
net

## ------------------------------------------------------------------------
library(ergm)
reg1 <- ergm(net ~ edges)
summary(reg1)

#   no. of edges / ( no. of potential edges - no. of existing edges)
log(length(E(g)) / ( length(V(g))*(length(V(g))-1) - length(E(g))))

## ------------------------------------------------------------------------
reg2 <- ergm(net ~ edges + mutual)
summary(reg2)

## ------------------------------------------------------------------------
reg3 <- ergm(net ~ edges + mutual + nodematch("party"))
summary(reg3) 

## ------------------------------------------------------------------------
reg4 <- ergm(net ~ edges + mutual + nodefactor("chamber") +
               absdiff("followers_count") + nodematch("party") + 
               nodematch("chamber") + nodematch("gender"))
summary(reg4)

## ------------------------------------------------------------------------
mcmc.diagnostics(reg2)

## ---- eval=FALSE---------------------------------------------------------
## sims <- simulate(reg2, nsim=10)
## summary(sims)
## reggof <- gof(reg2 ~ idegree)
## plot(reggof)

