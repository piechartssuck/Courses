## ---- echo=FALSE, message=FALSE------------------------------------------
library(igraph)
edges <- read.csv("star-wars-network-edges.csv")
nodes <- read.csv("star-wars-network-nodes.csv")
g <- graph_from_data_frame(d=edges, vertices=nodes, directed=FALSE)

## ------------------------------------------------------------------------
sort(degree(g))

## ------------------------------------------------------------------------
sort(strength(g))

## ------------------------------------------------------------------------
sort(closeness(g, normalized=TRUE))

## ------------------------------------------------------------------------
sort(betweenness(g))

## ------------------------------------------------------------------------
sort(eigen_centrality(g)$vector)

## ------------------------------------------------------------------------
sort(page_rank(g)$vector)

## ------------------------------------------------------------------------
sort(authority_score(g)$vector)

## ------------------------------------------------------------------------
neighbors(g, v=which(V(g)$name=="DARTH VADER"))
ego(g, order=2, nodes=which(V(g)$name=="DARTH VADER"))

## ------------------------------------------------------------------------
diameter(g, directed=FALSE, weights=NA)
get_diameter(g, directed=FALSE, weights=NA)
mean_distance(g, directed=FALSE)
dist <- distances(g, weights=NA)
dist[1:5, 1:5]

## ------------------------------------------------------------------------
edge_density(g)
# 22*21 possible edges / 2 because it's undirected = 231 possible edges
# but only 60 exist
60/((22*21)/2)

## ------------------------------------------------------------------------
reciprocity(g)
# Why is it 1?

## ------------------------------------------------------------------------
transitivity(g)

## ------------------------------------------------------------------------
components(g)
par(mar=c(0,0,0,0)); plot(g)

## ------------------------------------------------------------------------
giant <- decompose(g)[[1]]

## ------------------------------------------------------------------------
cluster_walktrap(giant)
cluster_walktrap(giant, steps=10)

## ------------------------------------------------------------------------
cluster_fast_greedy(giant)
cluster_edge_betweenness(giant)
cluster_infomap(giant)
cluster_label_prop(giant)

## ------------------------------------------------------------------------
comm <- cluster_infomap(giant)
modularity(comm) # modularity score
par(mar=c(0,0,0,0)); plot(comm, giant)

## ------------------------------------------------------------------------
V(giant)$color <- membership(comm)
par(mar=c(0,0,0,0)); plot(giant)

## ---- fig.height=5, figh.width=6-----------------------------------------
coreness(g)
which(coreness(g)==6) # what is the core of the network?
which(coreness(g)==1) # what is the periphery of the network?

# Visualizing network structure
V(g)$coreness <- coreness(g)
par(mfrow=c(2, 3), mar=c(0.1,0.1,1,0.1))
set.seed(777); fr <- layout_with_fr(g)
for (k in 1:6){
  V(g)$color <- ifelse(V(g)$coreness>=k, "orange", "grey")
  plot(g, main=paste0(k, '-core shell'), layout=fr)
}

