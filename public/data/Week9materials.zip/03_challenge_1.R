## ------------------------------------------------------------------------
library(readr)
nodes <- read.csv("congress-twitter-network-nodes.csv")
edges <- read.csv("congress-twitter-network-edges.csv")

## ------------------------------------------------------------------------

library(igraph)
g <- graph_from_data_frame(d=edges, vertices=nodes, directed=TRUE)
plot(g)
## ------------------------------------------------------------------------


## ------------------------------------------------------------------------


## ----eval=FALSE----------------------------------------------------------
## set.seed(777)
## fr <- layout_with_fr(g, niter=1000)
## V(g)$color <- ifelse(V(g)$party=="Republican", "red", "blue") # clue
## V(g)$shape <- ifelse(V(g)$chamber=="sen", "square", "circle") # clue
## V(g)$label <- NA
## V(g)$size <- authority_score(g)$vector * 5
## 
## pdf("congress-network.pdf")
## par(mar=c(0,0,0,0))
## plot(g, edge.curved=.25, edge.width=.05, edge.arrow.mode=0)
## dev.off()

