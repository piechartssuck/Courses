# Do all of your work here before transferring the appropriate parts
# over to the Rmarkdown file!