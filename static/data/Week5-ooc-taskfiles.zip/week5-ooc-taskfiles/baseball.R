install.packages(Lahman)
library(Lahman)  
library(dplyr)

# Pipes everwhere!
so_by_team <- select(Teams, yearID, name, G, SO) %>%
  mutate(strikeouts_per_game = SO/G) 

avg_so_by_year  <- so_by_team %>% 
  group_by(yearID) %>%
  summarise(avg_so = mean(strikeouts_per_game))

# you can either use both so_by_team & avg_so_by_year,
# or use only so_by_team and look at ?stat_summary